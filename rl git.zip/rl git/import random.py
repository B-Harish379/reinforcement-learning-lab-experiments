import random

class Environment:
    def __init__(self):
        self.state = 0
        self.action_space = [-1, 1]

    def reset(self):
        self.state = 0
        return self.state   
    
    def step(self, action):
        self.state += action
        if self.state == 5:
            reward = 10
            done = True
        else:
            reward = 0
            done = False
        return self.state, reward, done

env = Environment()
state = env.reset()
done = False

print(f"Starting State: {state}")

while not done:
    action = random.choice(env.action_space)
    state, reward, done = env.step(action)
    print(f"Action taken: {action:2} | New State: {state:2} | Reward: {reward:2} | Done: {done}")

  