import numpy as np
from collections import defaultdict

class SimpleGridworld:
    """A simple 4x4 Gridworld environment for MC Prediction."""
    def __init__(self):
        self.grid_size = 4
        self.terminal_state = (3, 3)  # Bottom-right corner is the goal
        self.reset()
        
    def reset(self):
        self.agent_pos = (0, 0)  # Start at top-left
        return self.agent_pos
        
    def step(self, action):
        # Actions: 0=Up, 1=Down, 2=Left, 3=Right
        r, c = self.agent_pos
        if action == 0: r = max(0, r - 1)
        elif action == 1: r = min(self.grid_size - 1, r + 1)
        elif action == 2: c = max(0, c - 1)
        elif action == 3: c = min(self.grid_size - 1, c + 1)
        
        self.agent_pos = (r, c)
        
        done = (self.agent_pos == self.terminal_state)
        reward = 0 if done else -1  # Step penalty to encourage finding the goal
        
        return self.agent_pos, reward, done

def random_policy(state):
    """Policy to evaluate: Choose an action uniformly at random."""
    return np.random.choice([0, 1, 2, 3])

def generate_episode(env, policy):
    """Simulates one full episode under the given policy."""
    episode = []
    state = env.reset()
    done = False
    
    while not done:
        action = policy(state)
        next_state, reward, done = env.step(action)
        episode.append((state, action, reward))
        state = next_state
        
    return episode

def every_visit_mc_prediction(env, policy, num_episodes, gamma=1.0):
    """Calculates state values using Every-Visit Monte Carlo Prediction."""
    V = defaultdict(float)
    returns_sum = defaultdict(float)
    returns_count = defaultdict(float)
    
    for _ in range(num_episodes):
        # 1. Generate an episode following the policy
        episode = generate_episode(env, policy)
        
        G = 0
        # Loop backwards through the entire episode
        for t in reversed(range(len(episode))):
            state, action, reward = episode[t]
            G = gamma * G + reward
            
            # --- EVERY-VISIT UPDATE RULE ---
            # No checking if the state was already visited. 
            # We track and average every occurrence.
            returns_sum[state] += G
            returns_count[state] += 1
            V[state] = returns_sum[state] / returns_count[state]
                
    return V

# --- Execution ---
env = SimpleGridworld()
num_episodes = 5000
value_function = every_visit_mc_prediction(env, random_policy, num_episodes)

# Display the values in a readable 4x4 grid layout
grid_values = np.zeros((4, 4))
for r in range(4):
    for c in range(4):
        grid_values[r, c] = value_function[(r, c)]

print(f"Estimated Value Function V(s) after {num_episodes} episodes:\n")
print(np.round(grid_values, 2))
